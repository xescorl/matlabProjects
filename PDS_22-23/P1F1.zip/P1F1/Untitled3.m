%declaracio de variables
G = -10;
fo = 1000;
BW = 1000;
fTo = 1000;

% carreguem la senyal de memoria
[x,fs] = audioread('speech_dft.wav');
% mesurem la llargada de la senyal
ns = 0:length(x);
% creem el to pur de 1k
toPur = sin((2*pi*fTo*ns)/fs);
% sumem el to pur i el senyal
suma = transpose(toPur) + x;
% obtenim els vectors forward i backward del filtre amb els parametres
% proporcionats
[B,A] = parameq(fs,fo,BW,G);
% filtrem el senyal
y = filter(B,A,suma);
sound(y);